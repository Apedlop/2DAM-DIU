package com.example.examen_ex1ev1.controller;

import com.example.examen_ex1ev1.Main;
import javafx.fxml.FXML;

public class RootLayoutController {
    private Main main;

    public void setMain(Main main) {
        this.main = main;
    }

    @FXML
    private void verTiposMonedas() {

    }

}
